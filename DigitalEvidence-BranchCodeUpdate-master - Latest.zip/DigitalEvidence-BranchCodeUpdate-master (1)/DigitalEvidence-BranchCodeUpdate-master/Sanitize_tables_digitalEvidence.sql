
  update IZUUsers 
  set [BranchCode] =  substring([BranchCode], patindex('%[^0]%',[BranchCode]), 10)

  update [BankBranches] 
  set [BranchCode] =  substring([BranchCode], patindex('%[^0]%',[BranchCode]), 10)

  update BranchManagers 
  set [BranchCode] =  substring([BranchCode], patindex('%[^0]%',[BranchCode]), 10)

  update BranchPOCs 
  set [BranchCode] =  substring([BranchCode], patindex('%[^0]%',[BranchCode]), 10)

  update DigitalKeys 
  set [BranchCode] =  substring([BranchCode], patindex('%[^0]%',[BranchCode]), 10)

  update SystemKeys 
  set [BranchCode] =  substring([BranchCode], patindex('%[^0]%',[BranchCode]), 10)





  /****** Script for SelectTopNRows command from SSMS  ******/
SELECT Count(*)
  FROM [BankEyeIzUTest].[dbo].[BankBranches]
  where LEN(BranchCode) < 3

  SELECT Count(*)
  FROM [BankEyeIzUTest].[dbo].[BankBranches]
  where LEN(NewBranchCode) < 3

 Update BankBranches        
       set BranchCode =   replicate('0', 3 - len(BranchCode)) + cast (BranchCode as varchar)
where len(Branchcode) < 3

 Update BankBranches        
       set NewBranchCode =   replicate('0', 3 - len(NewBranchCode)) + cast (NewBranchCode as varchar)
where len(NewBranchCode) < 3




