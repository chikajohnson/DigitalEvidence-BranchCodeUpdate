update BankBranches
set NewBranchCode = CONCAT(BranchCode, '_NEW')